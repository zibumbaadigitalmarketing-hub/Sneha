import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const destinations = [
  { id: 1, name: "Kashi", featured: true },
  { id: 2, name: "Agra" },
  { id: 3, name: "Kedarnath", featured: true },
  { id: 4, name: "Varanasi" },
  { id: 5, name: "Nepal" },
  { id: 6, name: "Naimisharanya" },
  { id: 7, name: "Prayagraj", featured: true },
  { id: 8, name: "Lotus Temple" },
  { id: 9, name: "Gaya" },
  { id: 10, name: "Bodhgaya" },
  { id: 11, name: "Allahabad" },
  { id: 12, name: "Ayodhya" },
];

export function GalleryPreview() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-sm font-medium text-primary uppercase tracking-widest mb-2">
            View Highlights of Our Pilgrimages
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            Gallery
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore stunning photographs from our spiritual journeys across India's most sacred destinations
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-8">
          {destinations.map((destination) => (
            <Link 
              key={destination.id} 
              href="/gallery"
              data-testid={`gallery-card-${destination.id}`}
              className="group block relative aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg overflow-hidden hover-elevate transition-all cursor-pointer"
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl text-primary/20 font-bold mb-2">
                    {destination.id}
                  </div>
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-4">
                <h3 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors">
                  {destination.name}
                </h3>
                <p className="text-sm text-primary">View Packages</p>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center">
          <Link href="/gallery">
            <Button size="lg" data-testid="button-view-full-gallery">
              View Full Gallery
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
