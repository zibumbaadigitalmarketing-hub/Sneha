import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const slides = [
  {
    id: 1,
    title: "Witness the Charm of",
    subtitle: "Ancient Temples",
    label: "Explore Historic Temples",
  },
  {
    id: 2,
    title: "Journey through Sacred",
    subtitle: "Sanctuaries",
    label: "Explore Historic Temples",
  },
  {
    id: 3,
    title: "Celebrate Culture at",
    subtitle: "Holy Landmarks",
    label: "Explore Historic Temples",
  },
  {
    id: 4,
    title: "Embark on a Spiritual",
    subtitle: "Trail",
    label: "Explore Historic Temples",
  },
  {
    id: 5,
    title: "Connect with Faith",
    subtitle: "And Tradition",
    label: "Explore Historic Temples",
  },
  {
    id: 6,
    title: "Discover the Spiritual",
    subtitle: "Heart of India",
    label: "Explore Historic Temples",
  },
];

export function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="relative h-[80vh] md:h-[85vh] overflow-hidden bg-gradient-to-br from-primary/20 to-primary/5">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,140,0,0.1),transparent_50%)]" />
      
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-full">
          <div className="text-center space-y-6 animate-in fade-in duration-500">
            <div className="inline-block">
              <p className="text-sm md:text-base font-medium text-primary uppercase tracking-widest mb-2">
                {slides[currentSlide].label}
              </p>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight">
              <div className="mb-2">{slides[currentSlide].title}</div>
              <div className="text-primary">{slides[currentSlide].subtitle}</div>
            </h1>

            <div className="pt-6">
              <Link href="/packages">
                <Button
                  size="lg"
                  data-testid="button-discover-more"
                  className="text-base px-8 py-6 rounded-md shadow-lg hover:shadow-xl transition-all"
                >
                  Discover More
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <button
          onClick={prevSlide}
          data-testid="button-slider-prev"
          className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-background/80 backdrop-blur-sm rounded-full hover-elevate shadow-lg transition-all"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>

        <button
          onClick={nextSlide}
          data-testid="button-slider-next"
          className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-background/80 backdrop-blur-sm rounded-full hover-elevate shadow-lg transition-all"
          aria-label="Next slide"
        >
          <ChevronRight className="w-6 h-6 text-foreground" />
        </button>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              data-testid={`button-slider-dot-${index}`}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide
                  ? "bg-primary w-8"
                  : "bg-border hover-elevate"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
