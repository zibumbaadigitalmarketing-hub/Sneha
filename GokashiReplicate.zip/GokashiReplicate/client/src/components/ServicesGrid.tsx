import { Car, Eye, Users, Ship, Heart, LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useServices } from "@/hooks/useServices";

const iconMap: Record<string, LucideIcon> = {
  car: Car,
  eye: Eye,
  users: Users,
  ship: Ship,
  heart: Heart,
};

export function ServicesGrid() {
  const { data: services, isLoading, isError } = useServices();

  return (
    <section className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            Our Services
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Comprehensive pilgrimage services designed to make your spiritual journey comfortable and memorable
          </p>
        </div>

        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5].map((i) => (
              <Card key={i} className="p-8">
                <div className="flex flex-col items-center text-center space-y-4">
                  <Skeleton className="w-16 h-16 rounded-full" />
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-16 w-full" />
                </div>
              </Card>
            ))}
          </div>
        )}

        {isError && (
          <Card className="p-12 text-center">
            <p className="text-destructive" data-testid="text-services-error">Failed to load services. Please try again later.</p>
          </Card>
        )}

        {!isLoading && !isError && services && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => {
              const Icon = iconMap[service.icon] || Heart;
              return (
                <Card
                  key={service.id}
                  data-testid={`service-card-${service.id}`}
                  className="p-8 hover-elevate transition-all group cursor-pointer"
                >
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-8 h-8 text-primary" data-testid={`icon-service-${service.id}`} />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground" data-testid={`text-service-title-${service.id}`}>
                      {service.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed" data-testid={`text-service-desc-${service.id}`}>
                      {service.description}
                    </p>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
