import { Users, Star } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function AboutSection() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div>
              <p className="text-sm font-medium text-primary uppercase tracking-widest mb-2">
                Luxury, Comfort, and Spirituality
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
                Indulge in Comfort, Embrace
                <span className="block text-primary">Spirituality</span>
              </h2>
            </div>

            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Welcome to Spiritual Tours, a proud unit of ICICERONE ECOTOURS & HOLIDAYS (OPC) PVT LTD! 
                As a trusted B2B partner in the travel and tourism sector, we are dedicated to providing 
                top-notch services that cater to the unique needs of our valued clients.
              </p>
              <p>
                Recognized as one of the leading tour and travel agencies, we take pride in curating 
                exceptional experiences that create lasting memories. Driven by a vision to redefine 
                the travel industry, our journey is characterized by a strong focus on customer 
                satisfaction, continuous evolution, and an unwavering commitment to quality.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6 pt-4">
              <Card className="p-6 text-center">
                <div className="flex justify-center mb-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-primary mb-1">50k+</div>
                <div className="text-sm text-muted-foreground">Happy Travellers</div>
              </Card>

              <Card className="p-6 text-center">
                <div className="flex justify-center mb-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Star className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-primary mb-1">4.9</div>
                <div className="text-sm text-muted-foreground">Customer Ratings</div>
              </Card>
            </div>

            <div className="pt-4">
              <Link href="/about">
                <Button variant="outline" size="lg" data-testid="button-read-more">
                  Read More About Us
                </Button>
              </Link>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg overflow-hidden">
              <div className="w-full h-full flex items-center justify-center text-6xl text-primary/20 font-bold">
                ST
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-lg -z-10" />
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-primary/5 rounded-lg -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
}
