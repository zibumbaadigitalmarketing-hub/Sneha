import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const navLinks = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About" },
    { path: "/services", label: "Services" },
    { path: "/packages", label: "Packages" },
    { path: "/gallery", label: "Gallery" },
    { path: "/contact", label: "Contact" },
  ];

  const isActive = (path: string) => {
    if (path === "/") return location === "/";
    return location.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link 
            href="/" 
            data-testid="link-home"
            className="flex items-center space-x-3 hover-elevate rounded-md px-3 py-2 transition-all"
          >
            <div className="w-12 h-12 bg-primary rounded-md flex items-center justify-center">
              <span className="text-2xl font-bold text-primary-foreground">ST</span>
            </div>
            <div className="hidden sm:block">
              <div className="text-xl font-bold text-foreground">Spiritual Tours</div>
              <div className="text-xs text-muted-foreground uppercase tracking-wide">Sacred Journeys</div>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link 
                key={link.path} 
                href={link.path}
                data-testid={`link-nav-${link.label.toLowerCase()}`}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors hover-elevate ${
                  isActive(link.path)
                    ? "text-primary bg-primary/10"
                    : "text-foreground hover:text-primary"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center space-x-4">
            <Link href="/contact">
              <Button data-testid="button-online-booking" className="gap-2">
                <Phone className="w-4 h-4" />
                Online Booking
              </Button>
            </Link>
          </div>

          <button
            data-testid="button-mobile-menu"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 hover-elevate rounded-md"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden border-t bg-background">
          <nav className="px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <Link 
                key={link.path} 
                href={link.path}
                data-testid={`link-mobile-${link.label.toLowerCase()}`}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-4 py-3 rounded-md text-sm font-medium transition-colors hover-elevate ${
                  isActive(link.path)
                    ? "text-primary bg-primary/10"
                    : "text-foreground"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link href="/contact">
              <Button
                data-testid="button-mobile-booking"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full gap-2 mt-4"
              >
                <Phone className="w-4 h-4" />
                Online Booking
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
