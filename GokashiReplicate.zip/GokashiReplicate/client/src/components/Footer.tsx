import { Link } from "wouter";
import { MapPin, Phone, Mail } from "lucide-react";

export function Footer() {
  const galleryThumbnails = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    alt: `Destination ${i + 1}`,
  }));

  return (
    <footer className="bg-card border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-primary rounded-md flex items-center justify-center">
                <span className="text-xl font-bold text-primary-foreground">ST</span>
              </div>
              <div>
                <div className="text-lg font-bold text-foreground">Spiritual Tours</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Trusted B2B partner in travel and tourism, dedicated to providing top-notch pilgrimage experiences across India.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide mb-4">
              Addresses
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex items-start gap-2 mb-2">
                  <MapPin className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="text-xs font-semibold text-foreground uppercase">Varanasi</span>
                </div>
                <p className="text-sm text-muted-foreground ml-6">
                  Akhari Village, Near BNS Mahila College<br />
                  Varanasi - 221011
                </p>
              </div>
              <div>
                <div className="flex items-start gap-2 mb-2">
                  <MapPin className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="text-xs font-semibold text-foreground uppercase">Chennai</span>
                </div>
                <p className="text-sm text-muted-foreground ml-6">
                  No: 12, Loganathan Street<br />
                  Krishnapuram, Ambattur - 600053
                </p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide mb-4">
              Quick Links
            </h3>
            <nav className="space-y-2">
              {[
                { path: "/about", label: "About Us" },
                { path: "/services", label: "Services" },
                { path: "/packages", label: "Packages" },
                { path: "/gallery", label: "Gallery" },
                { path: "/contact", label: "Contact" },
              ].map((link) => (
                <Link 
                  key={link.path} 
                  href={link.path}
                  data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                  className="block text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide mb-4">
              Contact Info
            </h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <a
                    href="tel:+919677686640"
                    data-testid="link-phone"
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    +91 96776 86640
                  </a>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <a
                    href="mailto:info@spiritualtours.com"
                    data-testid="link-email"
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    info@spiritualtours.com
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h4 className="text-xs font-semibold text-foreground uppercase tracking-wide mb-3">
                Gallery Preview
              </h4>
              <div className="grid grid-cols-4 gap-2">
                {galleryThumbnails.slice(0, 8).map((thumb) => (
                  <div
                    key={thumb.id}
                    className="aspect-square bg-muted rounded hover-elevate cursor-pointer transition-all"
                    data-testid={`gallery-thumb-${thumb.id}`}
                  >
                    <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">
                      {thumb.id}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Spiritual Tours. A unit of ICICERONE ECOTOURS & HOLIDAYS (OPC) PVT LTD. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
