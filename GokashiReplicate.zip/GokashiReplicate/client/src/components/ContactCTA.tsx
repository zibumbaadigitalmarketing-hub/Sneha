import { Phone } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function ContactCTA() {
  return (
    <section className="py-20 bg-gradient-to-br from-primary to-primary/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground">
            Ready to Start Your Spiritual Journey?
          </h2>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
            Contact us today to book your pilgrimage package or learn more about our services. 
            Our team is ready to help you plan an unforgettable spiritual experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link href="/contact">
              <Button
                size="lg"
                variant="secondary"
                className="gap-2 px-8"
                data-testid="button-contact-us"
              >
                Contact Us Now
              </Button>
            </Link>
            <a href="tel:+919677686640">
              <Button
                size="lg"
                variant="outline"
                className="gap-2 px-8 bg-primary-foreground text-primary hover:bg-primary-foreground/90 border-primary-foreground"
                data-testid="button-call-now"
              >
                <Phone className="w-5 h-5" />
                +91 96776 86640
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
