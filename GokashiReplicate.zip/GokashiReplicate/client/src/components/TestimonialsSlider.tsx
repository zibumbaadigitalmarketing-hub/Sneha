import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useTestimonials } from "@/hooks/useTestimonials";

export function TestimonialsSlider() {
  const { data: testimonials, isLoading, isError } = useTestimonials();
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (!testimonials || testimonials.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(interval);
  }, [testimonials]);

  const nextTestimonial = () => {
    if (!testimonials) return;
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    if (!testimonials) return;
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const current = testimonials?.[currentIndex];

  return (
    <section className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <span className="text-2xl font-bold text-primary">ST</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            Testimonials
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our team of more than 20 professionals is committed to providing the highest level of service, 
            ensuring that every trip is a success.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {isLoading && (
            <Card className="p-8 md:p-12">
              <div className="space-y-8">
                <Skeleton className="h-24 w-full" />
                <div className="flex flex-col items-center gap-4">
                  <Skeleton className="w-16 h-16 rounded-full" />
                  <Skeleton className="h-6 w-32" />
                </div>
              </div>
            </Card>
          )}

          {isError && (
            <Card className="p-8 md:p-12 text-center">
              <p className="text-destructive" data-testid="text-testimonials-error">Failed to load testimonials.</p>
            </Card>
          )}

          {!isLoading && !isError && current && (
            <>
              <Card className="p-8 md:p-12 relative">
                <Quote className="absolute top-6 left-6 w-12 h-12 text-primary/20" />
                
                <div className="space-y-8 animate-in fade-in duration-500" key={current.id}>
                  <blockquote className="text-lg md:text-xl text-muted-foreground leading-relaxed text-center italic" data-testid={`text-testimonial-quote-${current.id}`}>
                    "{current.quote}"
                  </blockquote>

                  <div className="flex flex-col items-center gap-4">
                    <Avatar className="w-16 h-16">
                      <AvatarFallback className="bg-primary/10 text-primary text-lg font-semibold">
                        {current.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <div className="font-semibold text-foreground" data-testid={`text-testimonial-name-${current.id}`}>{current.name}</div>
                      <div className="text-sm text-muted-foreground">Satisfied Traveller</div>
                    </div>
                  </div>
                </div>
              </Card>

              <div className="flex justify-center gap-4 mt-8">
                <button
                  onClick={prevTestimonial}
                  data-testid="button-testimonials-prev"
                  className="p-3 bg-background rounded-full hover-elevate shadow transition-all"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-5 h-5 text-foreground" />
                </button>

                <div className="flex items-center gap-2">
                  {testimonials?.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentIndex(index)}
                      data-testid={`button-testimonial-dot-${index}`}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentIndex ? "bg-primary w-6" : "bg-border"
                      }`}
                      aria-label={`Go to testimonial ${index + 1}`}
                    />
                  ))}
                </div>

                <button
                  onClick={nextTestimonial}
                  data-testid="button-testimonials-next"
                  className="p-3 bg-background rounded-full hover-elevate shadow transition-all"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-5 h-5 text-foreground" />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
