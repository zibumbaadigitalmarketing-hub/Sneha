import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { usePackages } from "@/hooks/usePackages";

export function PackagesCarousel() {
  const { data: packages, isLoading, isError } = usePackages();
  const [startIndex, setStartIndex] = useState(0);
  const itemsPerPage = 3;

  const nextSlide = () => {
    if (!packages) return;
    setStartIndex((prev) => 
      prev + itemsPerPage >= packages.length ? 0 : prev + itemsPerPage
    );
  };

  const prevSlide = () => {
    if (!packages) return;
    setStartIndex((prev) => 
      prev === 0 ? Math.max(0, packages.length - itemsPerPage) : Math.max(0, prev - itemsPerPage)
    );
  };

  const visiblePackages = packages?.slice(startIndex, startIndex + itemsPerPage) || [];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-12">
          <div>
            <p className="text-sm font-medium text-primary uppercase tracking-widest mb-2" data-testid="text-packages-label">
              Our travel packages
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Best Offers
            </h2>
          </div>
          
          <div className="flex gap-4">
            <Link href="/packages">
              <Button variant="outline" data-testid="button-view-all-packages">
                View All Packages
              </Button>
            </Link>
          </div>
        </div>

        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="aspect-[4/3] w-full" />
                <div className="p-6 space-y-4">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-10 w-full" />
                </div>
              </Card>
            ))}
          </div>
        )}

        {isError && (
          <Card className="p-12 text-center">
            <p className="text-destructive mb-4" data-testid="text-packages-error">Failed to load packages. Please try again later.</p>
            <Button onClick={() => window.location.reload()} data-testid="button-reload-packages">Reload</Button>
          </Card>
        )}

        {!isLoading && !isError && packages && packages.length > 0 && (
          <div className="relative">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {visiblePackages.map((pkg, index) => (
                <Card
                  key={pkg.id}
                  data-testid={`package-card-${pkg.id}`}
                  className="overflow-hidden hover-elevate transition-all group"
                >
                  <div className="relative aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5">
                    <div className="absolute inset-0 flex items-center justify-center text-4xl text-primary/20 font-bold">
                      {startIndex + index + 1}
                    </div>
                    <Badge className="absolute top-4 right-4 bg-background/90 text-foreground border" data-testid={`badge-duration-${pkg.id}`}>
                      {pkg.duration}
                    </Badge>
                  </div>
                  <div className="p-6 space-y-4">
                    <h3 className="text-lg font-semibold text-foreground line-clamp-2 min-h-[3.5rem]" data-testid={`text-package-title-${pkg.id}`}>
                      {pkg.title}
                    </h3>
                    <Link href={`/packages/${pkg.id}`}>
                      <Button
                        variant="outline"
                        className="w-full"
                        data-testid={`button-package-${pkg.id}`}
                      >
                        Contact Us
                      </Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>

            <div className="flex justify-center gap-4 mt-8">
              <button
                onClick={prevSlide}
                data-testid="button-packages-prev"
                className="p-3 bg-card rounded-full hover-elevate shadow transition-all disabled:opacity-50"
                disabled={startIndex === 0}
                aria-label="Previous packages"
              >
                <ChevronLeft className="w-5 h-5 text-foreground" />
              </button>
              <button
                onClick={nextSlide}
                data-testid="button-packages-next"
                className="p-3 bg-card rounded-full hover-elevate shadow transition-all disabled:opacity-50"
                disabled={startIndex + itemsPerPage >= packages.length}
                aria-label="Next packages"
              >
                <ChevronRight className="w-5 h-5 text-foreground" />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
