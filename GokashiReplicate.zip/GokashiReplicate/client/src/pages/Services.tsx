import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Car, Eye, Users, Ship, Heart, CheckCircle } from "lucide-react";
import { Card } from "@/components/ui/card";

const services = [
  {
    id: 1,
    title: "Cab Booking",
    description: "Comfortable and reliable transportation services for your spiritual journey",
    icon: Car,
    features: [
      "Well-maintained vehicles",
      "Professional drivers",
      "24/7 availability",
      "Flexible pickup and drop-off",
      "Competitive pricing",
    ],
  },
  {
    id: 2,
    title: "VIP Dharshan Booking",
    description: "Skip the queues with our exclusive VIP darshan arrangements",
    icon: Eye,
    features: [
      "Priority temple access",
      "Minimal waiting time",
      "Dedicated assistance",
      "Special darshan timings",
      "Hassle-free experience",
    ],
  },
  {
    id: 3,
    title: "Tour Escorts",
    description: "Expert guides to enrich your spiritual experience with knowledge",
    icon: Users,
    features: [
      "Knowledgeable guides",
      "Multi-language support",
      "Historical insights",
      "Cultural context",
      "Personalized attention",
    ],
  },
  {
    id: 4,
    title: "Boat Booking",
    description: "Sacred boat rides on holy rivers for a divine experience",
    icon: Ship,
    features: [
      "Safe and secure boats",
      "Sunrise and sunset rides",
      "Ganga Aarti experiences",
      "Photography opportunities",
      "Experienced boat operators",
    ],
  },
  {
    id: 5,
    title: "Pinda Dhan",
    description: "Traditional ritual services performed with utmost devotion",
    icon: Heart,
    features: [
      "Experienced pandits",
      "Complete ritual arrangements",
      "Authentic procedures",
      "Required materials provided",
      "Spiritual guidance",
    ],
  },
];

export default function Services() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
                Our Services
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Comprehensive pilgrimage services designed to make your spiritual journey 
                comfortable, meaningful, and memorable
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-12">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <Card
                    key={service.id}
                    data-testid={`service-detail-${service.id}`}
                    className={`p-8 md:p-12 ${index % 2 === 0 ? '' : 'bg-card/50'}`}
                  >
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                      <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-8 h-8 text-primary" />
                          </div>
                          <h2 className="text-2xl md:text-3xl font-bold text-foreground">
                            {service.title}
                          </h2>
                        </div>
                        <p className="text-muted-foreground leading-relaxed mb-6">
                          {service.description}
                        </p>
                        <ul className="space-y-3">
                          {service.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-3">
                              <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                        <div className="aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg overflow-hidden">
                          <div className="w-full h-full flex items-center justify-center text-6xl text-primary/20 font-bold">
                            {service.id}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
