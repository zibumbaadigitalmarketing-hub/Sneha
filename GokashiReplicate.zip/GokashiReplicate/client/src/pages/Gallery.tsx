import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

const galleryItems = [
  { id: 1, destination: "Kashi Vishwanath Temple", category: "Temples" },
  { id: 2, destination: "Ganga Aarti", category: "Rituals" },
  { id: 3, destination: "Kedarnath", category: "Temples" },
  { id: 4, destination: "Varanasi Ghats", category: "Ghats" },
  { id: 5, destination: "Nepal Temples", category: "International" },
  { id: 6, destination: "Naimisharanya", category: "Heritage" },
  { id: 7, destination: "Triveni Sangam", category: "Ghats" },
  { id: 8, destination: "Lotus Temple", category: "Temples" },
  { id: 9, destination: "Gaya", category: "Temples" },
  { id: 10, destination: "Bodhgaya", category: "Buddhist" },
  { id: 11, destination: "Allahabad Fort", category: "Heritage" },
  { id: 12, destination: "Ayodhya Ram Mandir", category: "Temples" },
  { id: 13, destination: "Dashashwamedh Ghat", category: "Ghats" },
  { id: 14, destination: "Sarnath", category: "Buddhist" },
  { id: 15, destination: "Chitrakoot", category: "Heritage" },
  { id: 16, destination: "Morning Puja", category: "Rituals" },
];

const categories = ["All", "Temples", "Ghats", "Rituals", "Buddhist", "Heritage", "International"];

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const filteredItems = selectedCategory === "All"
    ? galleryItems
    : galleryItems.filter(item => item.category === selectedCategory);

  const openLightbox = (id: number) => {
    setSelectedImage(id);
    setLightboxOpen(true);
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    setSelectedImage(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
                Gallery
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Explore stunning photographs from our spiritual journeys across India's 
                most sacred and beautiful destinations
              </p>
            </div>
          </div>
        </section>

        <section className="py-12 bg-background border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category) => (
                <Button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  variant={selectedCategory === category ? "default" : "outline"}
                  data-testid={`button-category-${category.toLowerCase()}`}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => openLightbox(item.id)}
                  data-testid={`gallery-item-${item.id}`}
                  className="group relative aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg overflow-hidden hover-elevate transition-all cursor-pointer"
                >
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-4xl text-primary/20 font-bold">{item.id}</div>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/0 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform">
                    <h3 className="text-sm font-semibold text-foreground">
                      {item.destination}
                    </h3>
                    <p className="text-xs text-primary">{item.category}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />

      {lightboxOpen && selectedImage !== null && (
        <div
          className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            data-testid="button-close-lightbox"
            className="absolute top-4 right-4 p-2 bg-card rounded-full hover-elevate z-10"
            aria-label="Close lightbox"
          >
            <X className="w-6 h-6 text-foreground" />
          </button>
          <div className="max-w-5xl w-full aspect-[16/9] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg overflow-hidden">
            <div className="w-full h-full flex items-center justify-center text-6xl text-primary/20 font-bold">
              {selectedImage}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
