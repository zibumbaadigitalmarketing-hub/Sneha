import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { usePackages } from "@/hooks/usePackages";

export default function Packages() {
  const { data: packages, isLoading, isError } = usePackages();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
                Tour Packages
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Discover our carefully curated spiritual tour packages designed to provide 
                authentic and transformative pilgrimage experiences
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {isLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <Skeleton className="aspect-[4/3] w-full" />
                    <div className="p-6 space-y-4">
                      <Skeleton className="h-6 w-3/4" />
                      <div className="flex gap-2">
                        <Skeleton className="h-10 flex-1" />
                        <Skeleton className="h-10 flex-1" />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {isError && (
              <Card className="p-12 text-center">
                <p className="text-destructive mb-4" data-testid="text-packages-error">
                  Failed to load packages. Please try again later.
                </p>
                <Button onClick={() => window.location.reload()} data-testid="button-reload-packages">
                  Reload Page
                </Button>
              </Card>
            )}

            {!isLoading && !isError && packages && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {packages.map((pkg) => (
                  <Card
                    key={pkg.id}
                    data-testid={`package-item-${pkg.id}`}
                    className="overflow-hidden hover-elevate transition-all group"
                  >
                    <div className="relative aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5">
                      <div className="absolute inset-0 flex items-center justify-center text-4xl text-primary/20 font-bold">
                        <span data-testid={`text-package-index-${pkg.id}`}>P</span>
                      </div>
                      <Badge className="absolute top-4 right-4 bg-background/90 text-foreground border" data-testid={`badge-duration-${pkg.id}`}>
                        {pkg.duration}
                      </Badge>
                    </div>
                    <div className="p-6 space-y-4">
                      <h3 className="text-lg font-semibold text-foreground line-clamp-2 min-h-[3.5rem]" data-testid={`text-package-title-${pkg.id}`}>
                        {pkg.title}
                      </h3>
                      <div className="flex gap-2">
                        <Link href={`/packages/${pkg.id}`}>
                          <Button
                            variant="default"
                            className="flex-1"
                            data-testid={`button-view-package-${pkg.id}`}
                          >
                            View Details
                          </Button>
                        </Link>
                        <Link href="/contact">
                          <Button
                            variant="outline"
                            className="flex-1"
                            data-testid={`button-contact-package-${pkg.id}`}
                          >
                            Contact
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
