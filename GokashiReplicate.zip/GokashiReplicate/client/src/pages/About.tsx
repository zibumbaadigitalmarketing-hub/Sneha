import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Users, Target, Award, Heart } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function About() {
  const values = [
    {
      icon: Heart,
      title: "Customer First",
      description: "We prioritize customer satisfaction above everything else",
    },
    {
      icon: Award,
      title: "Quality Service",
      description: "Delivering exceptional experiences with attention to detail",
    },
    {
      icon: Users,
      title: "Expert Team",
      description: "Professional guides with deep knowledge of spiritual destinations",
    },
    {
      icon: Target,
      title: "Mission Driven",
      description: "Committed to making spiritual tourism accessible to everyone",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
                About Spiritual Tours
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Your trusted partner in spiritual journeys across India's most sacred destinations
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
              <div className="space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                  Who We Are
                </h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    Welcome to Spiritual Tours, a proud unit of ICICERONE ECOTOURS & HOLIDAYS (OPC) PVT LTD! 
                    As a trusted B2B partner in the travel and tourism sector, we are dedicated to providing 
                    top-notch services that cater to the unique needs of our valued clients.
                  </p>
                  <p>
                    Recognized as one of the leading tour and travel agencies, we take pride in curating 
                    exceptional experiences that create lasting memories. Our journey is characterized by 
                    a strong focus on customer satisfaction, continuous evolution, and an unwavering 
                    commitment to quality.
                  </p>
                  <p>
                    Driven by a vision to redefine the travel industry, we strive to deliver unparalleled 
                    travel experiences for everyone we serve. With our expertise and passion for excellence, 
                    we have helped over 50,000 travelers embark on transformative spiritual journeys.
                  </p>
                </div>
              </div>

              <div className="relative">
                <div className="aspect-[4/3] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg overflow-hidden">
                  <div className="w-full h-full flex items-center justify-center text-6xl text-primary/20 font-bold">
                    ST
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-20">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground text-center mb-12">
                Our Core Values
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {values.map((value, index) => {
                  const Icon = value.icon;
                  return (
                    <Card key={index} className="p-6 text-center hover-elevate transition-all">
                      <div className="flex justify-center mb-4">
                        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                          <Icon className="w-8 h-8 text-primary" />
                        </div>
                      </div>
                      <h3 className="text-lg font-semibold text-foreground mb-2">
                        {value.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {value.description}
                      </p>
                    </Card>
                  );
                })}
              </div>
            </div>

            <div className="bg-card rounded-lg p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                Why Choose Us?
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                <div>
                  <div className="text-4xl font-bold text-primary mb-2">50k+</div>
                  <div className="text-muted-foreground">Happy Travelers</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-primary mb-2">4.9</div>
                  <div className="text-muted-foreground">Average Rating</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-primary mb-2">20+</div>
                  <div className="text-muted-foreground">Expert Professionals</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
