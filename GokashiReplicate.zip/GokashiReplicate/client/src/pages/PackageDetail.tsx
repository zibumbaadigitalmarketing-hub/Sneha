import { useRoute, Link } from "wouter";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, MapPin, Clock, Users, Phone } from "lucide-react";
import { usePackage } from "@/hooks/usePackages";

export default function PackageDetail() {
  const [, params] = useRoute("/packages/:id");
  const packageId = params?.id || "";
  const { data: pkg, isLoading, isError } = usePackage(packageId);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {isLoading && (
          <>
            <section className="py-24 bg-gradient-to-br from-primary/20 to-primary/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-4xl space-y-4">
                  <Skeleton className="h-8 w-24" />
                  <Skeleton className="h-16 w-3/4" />
                  <Skeleton className="h-24 w-full" />
                </div>
              </div>
            </section>
            <section className="py-20 bg-background">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <Skeleton className="h-96 w-full" />
              </div>
            </section>
          </>
        )}

        {isError && (
          <section className="py-24 bg-gradient-to-br from-primary/20 to-primary/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <Card className="p-12 text-center">
                <p className="text-destructive mb-4" data-testid="text-package-error">
                  Package not found or failed to load.
                </p>
                <Link href="/packages">
                  <Button data-testid="button-back-to-packages">Back to Packages</Button>
                </Link>
              </Card>
            </div>
          </section>
        )}

        {!isLoading && !isError && pkg && (
          <>
            <section className="relative py-24 bg-gradient-to-br from-primary/20 to-primary/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-4xl">
                  <Badge className="mb-4 bg-primary text-primary-foreground" data-testid="badge-package-duration">
                    {pkg.duration}
                  </Badge>
                  <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6" data-testid="text-package-title">
                    {pkg.title}
                  </h1>
                  <p className="text-lg text-muted-foreground leading-relaxed mb-8" data-testid="text-package-description">
                    {pkg.description}
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Link href="/contact">
                      <Button size="lg" className="gap-2" data-testid="button-book-now">
                        <Phone className="w-5 h-5" />
                        Book Now
                      </Button>
                    </Link>
                    <a href="tel:+919677686640">
                      <Button size="lg" variant="outline" className="gap-2" data-testid="button-call">
                        <Phone className="w-5 h-5" />
                        Call Us
                      </Button>
                    </a>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 bg-background">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                  <div className="lg:col-span-2 space-y-12">
                    <div>
                      <h2 className="text-3xl font-bold text-foreground mb-6">
                        Tour Highlights
                      </h2>
                      <Card className="p-6">
                        <ul className="space-y-4">
                          {pkg.highlights.map((highlight, index) => (
                            <li key={index} className="flex items-start gap-3" data-testid={`item-highlight-${index}`}>
                              <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{highlight}</span>
                            </li>
                          ))}
                        </ul>
                      </Card>
                    </div>

                    <div>
                      <h2 className="text-3xl font-bold text-foreground mb-6">
                        Detailed Itinerary
                      </h2>
                      <div className="space-y-6">
                        {pkg.itinerary.map((day, index) => (
                          <Card key={index} className="p-6" data-testid={`item-itinerary-${index}`}>
                            <div className="flex items-start gap-4">
                              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <span className="font-bold text-primary">{index + 1}</span>
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge variant="outline">Day {index + 1}</Badge>
                                </div>
                                <p className="text-muted-foreground leading-relaxed">{day}</p>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>

                    {pkg.price && (
                      <div>
                        <h2 className="text-3xl font-bold text-foreground mb-6">
                          Package Pricing
                        </h2>
                        <Card className="p-6">
                          <div className="flex items-baseline gap-2">
                            <span className="text-4xl font-bold text-primary" data-testid="text-package-price">
                              ₹{pkg.price.toLocaleString()}
                            </span>
                            <span className="text-muted-foreground">per person</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-2">
                            * Price may vary based on season and group size
                          </p>
                        </Card>
                      </div>
                    )}
                  </div>

                  <div className="lg:col-span-1">
                    <div className="sticky top-24 space-y-6">
                      <Card className="p-6">
                        <h3 className="text-xl font-bold text-foreground mb-6">
                          Package Info
                        </h3>
                        <div className="space-y-4">
                          <div className="flex items-start gap-3">
                            <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <div>
                              <div className="text-sm text-muted-foreground">Duration</div>
                              <div className="font-semibold text-foreground" data-testid="text-sidebar-duration">
                                {pkg.duration}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-start gap-3">
                            <Users className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <div>
                              <div className="text-sm text-muted-foreground">Group Size</div>
                              <div className="font-semibold text-foreground">Flexible</div>
                            </div>
                          </div>
                          <div className="flex items-start gap-3">
                            <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <div>
                              <div className="text-sm text-muted-foreground">Pickup</div>
                              <div className="font-semibold text-foreground">Varanasi</div>
                            </div>
                          </div>
                        </div>
                      </Card>

                      <Card className="p-6 bg-primary text-primary-foreground">
                        <h3 className="text-xl font-bold mb-4">
                          Ready to Book?
                        </h3>
                        <p className="text-sm mb-6 text-primary-foreground/90">
                          Contact us now to customize this package or get a detailed quote
                        </p>
                        <Link href="/contact">
                          <Button
                            variant="secondary"
                            size="lg"
                            className="w-full"
                            data-testid="button-contact-sidebar"
                          >
                            Contact Us
                          </Button>
                        </Link>
                      </Card>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
