import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HeroSlider } from "@/components/HeroSlider";
import { AboutSection } from "@/components/AboutSection";
import { ServicesGrid } from "@/components/ServicesGrid";
import { PackagesCarousel } from "@/components/PackagesCarousel";
import { TestimonialsSlider } from "@/components/TestimonialsSlider";
import { GalleryPreview } from "@/components/GalleryPreview";
import { ContactCTA } from "@/components/ContactCTA";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSlider />
        <AboutSection />
        <ServicesGrid />
        <PackagesCarousel />
        <TestimonialsSlider />
        <GalleryPreview />
        <ContactCTA />
      </main>
      <Footer />
    </div>
  );
}
