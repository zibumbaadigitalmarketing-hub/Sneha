import { Link } from "wouter";
import { Home, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5 px-4">
      <div className="text-center max-w-2xl">
        <div className="mb-8">
          <h1 className="text-9xl font-bold text-primary mb-4">404</h1>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Page Not Found
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            The page you're looking for doesn't exist or has been moved. 
            Let's get you back on your spiritual journey.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/">
            <Button size="lg" className="gap-2" data-testid="button-home">
              <Home className="w-5 h-5" />
              Go to Homepage
            </Button>
          </Link>
          <Button
            size="lg"
            variant="outline"
            className="gap-2"
            onClick={() => window.history.back()}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
            Go Back
          </Button>
        </div>

        <div className="mt-12 p-6 bg-card rounded-lg">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Looking for something specific?
          </h3>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/packages">
              <Button variant="outline" size="sm">
                Tour Packages
              </Button>
            </Link>
            <Link href="/services">
              <Button variant="outline" size="sm">
                Our Services
              </Button>
            </Link>
            <Link href="/gallery">
              <Button variant="outline" size="sm">
                Gallery
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" size="sm">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
