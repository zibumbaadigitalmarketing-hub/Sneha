import { useQuery } from "@tanstack/react-query";
import type { Package } from "@shared/schema";

export function usePackages() {
  return useQuery<Package[]>({
    queryKey: ["/api/packages"],
  });
}

export function usePackage(id: string) {
  return useQuery<Package>({
    queryKey: ["/api/packages", id],
    enabled: !!id,
  });
}
