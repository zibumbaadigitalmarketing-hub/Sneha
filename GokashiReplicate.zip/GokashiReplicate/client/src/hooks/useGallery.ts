import { useQuery } from "@tanstack/react-query";
import type { GalleryItem } from "@shared/schema";

export function useGallery() {
  return useQuery<GalleryItem[]>({
    queryKey: ["/api/gallery"],
  });
}
